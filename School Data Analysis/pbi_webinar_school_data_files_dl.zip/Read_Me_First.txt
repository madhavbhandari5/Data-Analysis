The Power BI Desktop file (pbi_webinar_school_data.pbix) is linked to the CSV files on my SharePoint site. As a result, you cannot refresh or edit the queries in this file because you don't have access to my SharePoint site. However, you can use the Power Pivot modeling tools and add/remove visualisations.

If you'd like to recreate these reports and you don't have a SharePoint site*, then I recommend you save the files to your PC hard drive or a network drive, then use Get Data > From Folder. The process is the same once you 'Browse' to your folder location.

*Note: Saving the files to OneDrive or OneDrive for Business is not the same as saving to a SharePoint site, despite the OneDrive URLs containing the 'SharePoint' in the link.